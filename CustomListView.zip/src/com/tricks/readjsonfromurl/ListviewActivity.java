package com.tricks.readjsonfromurl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.os.Bundle;
import android.os.StrictMode;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class ListviewActivity extends Activity {

	ListView listView;
	
	ArrayList<HashMap<String, String>> arrList;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_list);
		
		listView = (ListView) findViewById(R.id.listview);
		arrList = new ArrayList<HashMap<String, String>>();
		
		
		String json_str = getJsonData();
		
		try{
        	JSONArray jArray = new JSONArray(json_str);
        	
        	for (int i = 0; i < jArray.length(); i++) {
        		JSONObject json = null;
        		json = jArray.getJSONObject(i);
        		
	        	HashMap<String, String> map1 = new HashMap<String, String>();
            	
            	// adding each child node to HashMap key => value
                map1.put("id", json.getString("id"));
                map1.put("name", json.getString("name"));
                map1.put("url", json.getString("url"));
                
                // adding HashList to ArrayList
                arrList.add(map1);
        	}
        	
        	
        } catch ( JSONException e) {
        	e.printStackTrace();            	
        }
		
		
		if(!arrList.isEmpty()){
			ListAdapter adapter = new SimpleAdapter( this, arrList,
	                R.layout.list_item, new String[] { "id", "name", "url" },
	                new int[] { R.id.wid, R.id.name, R.id.url });
	        
	        listView.setAdapter(adapter);
		}
	}
	
	
	private String getJsonData(){
		StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
        .detectDiskReads()
        .detectDiskWrites()
        .detectNetwork()   // or .detectAll() for all detectable problems
        .penaltyLog()
        .build());
		
		String str = "";
		HttpResponse response;
        HttpClient myClient = new DefaultHttpClient();
        HttpPost myConnection = new HttpPost("http://demos.tricksofit.com/files/json2.php");
        
        try {
        	response = myClient.execute(myConnection);
            str = EntityUtils.toString(response.getEntity(), "UTF-8");
            
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return str;
	}
}
