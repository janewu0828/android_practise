httpPostTest
============

httpPost Test Example for Android Client