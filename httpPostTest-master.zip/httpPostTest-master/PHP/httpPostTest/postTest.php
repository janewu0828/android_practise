<?php 
echo "aaa=".@$_POST['data'].date("Y-m-d H:i:s");
?>