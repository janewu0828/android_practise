package com.eyingsoft;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
/**
 * 
 * @author .Fatty
 *
 */
public class MainActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}
	public void onClick(View v) {
		Intent intent = new Intent(getApplicationContext(), ListActivity.class);
		startActivity(intent);
	}
}
