package com.eyingsoft;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ListView;

import com.eyingsoft.adapter.AppListAdapter;
import com.eyingsoft.entity.Apps;

/**
 * 
 * @author .Fatty
 *  
 * List Apps Class
 *
 */
public class ListActivity extends Activity {
	private ListView listView;
	public static ProgressDialog progressDialog;
	public static LoadingProgressDialog pd;
	public Message msg;
	public Handler handler;
	public static final int DATA_ERROR = 0;
	public static final int DATA_CREATLIST = 1;
	List<Apps> data = null;// Apps实体类列表
	String strPackageName;// 包名
	// 列出手机中已经安装的apk信息（应用图片、应用名、包名等）
	List<PackageInfo> pis;
	List<ResolveInfo> appInfo;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		try {
			requestWindowFeature(Window.FEATURE_NO_TITLE);
			setContentView(R.layout.applist);

			pd = new LoadingProgressDialog(this, "正加载应用列表", false);
			progressDialog = pd.getProgressDialog();
			progressDialog.show();
			new Thread(new Runnable() {
				public void run() {
					try {
						PackageManager packageManager = getPackageManager();
						Intent intent = new Intent(Intent.ACTION_MAIN, null);
						intent.addCategory(Intent.CATEGORY_LAUNCHER);
						appInfo = packageManager.queryIntentActivities(intent,
								0);
						pis = packageManager.getInstalledPackages(0);

						if (appInfo != null) {
							data = new ArrayList<Apps>();
							for (ResolveInfo app : appInfo) {
								data.add(new Apps(app.loadIcon(packageManager),
										(String) app.loadLabel(packageManager)));
							}
							msg.what = DATA_CREATLIST;
						} else {
							msg.what = DATA_ERROR;
						}
					} catch (Exception e) {
						msg.what = DATA_ERROR;
					} finally {
						handler.sendMessage(msg);
					}
				}
			}).start();

			msg = Message.obtain();
			handler = new Handler() {
				public void handleMessage(Message message) {
					switch (message.what) {
					case DATA_CREATLIST:// 创建ListView

						listView = (ListView) findViewById(R.id.apps_listview);

						AppListAdapter adapter = new AppListAdapter(
								ListActivity.this, data, listView);
						listView.setAdapter(adapter);

						listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
							public void onItemClick(AdapterView<?> parent,
									View view, int position, long id) {
								ActivityInfo activityInfo = appInfo
										.get(position).activityInfo;
								Intent intent = new Intent();
								intent.setClassName(activityInfo.packageName,
										activityInfo.name);
								startActivity(intent);
//								overridePendingTransition(R.anim.app_show,     
//		                                R.anim.app_hide);

							}
						});

						break;
					case DATA_ERROR:
						showErrorDialog("Error Dialog");
						break;
					}
					super.handleMessage(message);
					progressDialog.dismiss();
				}
			};
			super.onCreate(savedInstanceState);

		} catch (Exception e) {
			finish();
		}
	}

	/**
	 * 错误对话框
	 * 
	 * @param strMsg
	 */
	protected void showErrorDialog(String strMsg) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("错误提示");
		builder.setMessage(strMsg);
		builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		builder.show();
	}

	/**
	 * @author .Fatty
	 * 
	 *         加载对话框
	 */
	public class LoadingProgressDialog {
		private ProgressDialog progressDialog;

		public LoadingProgressDialog(Context context, String str, boolean cancel) {
			progressDialog = new ProgressDialog(context);
			progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			progressDialog.setMessage(str);
			progressDialog.setCancelable(cancel);
		}

		public ProgressDialog getProgressDialog() {
			return progressDialog;
		}
	}
}
